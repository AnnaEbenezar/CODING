import Cabinet.Cabinet;
import Cabinet.SmallCabinet;
import Display.CRT;
import Display.Display;
import GPU.GPU;
import GPU.ARM;
import OS.OS;
import OS.Windows_XP;
import Payment.Payment;
import Payment.coins;

public class NJStraightSlot_ComFactory implements SlotComponentFactory {
    public NJStraightSlot_ComFactory() {
   }

   public Cabinet createCabinet() {
      return new SmallCabinet();
   }

   public Payment createPayment() {
      return new coins();
   }

   public Display createDisplay() {
      return new CRT();
   }

   public GPU createGPU() {
      return new ARM();
   }

   public OS createOS() {
      return new Windows_XP();
   }
}
