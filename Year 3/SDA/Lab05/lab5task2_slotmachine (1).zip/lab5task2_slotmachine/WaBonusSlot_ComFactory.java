import Cabinet.Cabinet;
import Cabinet.MediumCabinet;
import Display.Display;
import Display.VGA;
import GPU.ARM;
import GPU.GPU;
import OS.OS;
import OS.Symbian;
import Payment.Payment;
import Payment.ticketin_ticketout;

public class WaBonusSlot_ComFactory implements SlotComponentFactory{
   public WaBonusSlot_ComFactory() {
   }

   public Cabinet createCabinet() {
      return new MediumCabinet();
   }

   public Payment createPayment() {
      return new ticketin_ticketout();
   }

   public Display createDisplay() {
      return new VGA();
   }

   public GPU createGPU() {
      return new ARM();
   }

   public OS createOS() {
      return new Symbian();
   }
}
