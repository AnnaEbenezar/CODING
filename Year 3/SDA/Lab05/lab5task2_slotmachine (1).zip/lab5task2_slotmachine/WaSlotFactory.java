public class WaSlotFactory extends SlotFactory {
    public WaSlotFactory() {
    }
 
    protected Slot makeSlot(String item) {
       Slot slot = null;
       switch (item) {
          case "straight":
             SlotComponentFactory componentFactory = new WaStraightSlot_ComFactory();
             slot = new StraightSlot(componentFactory);
             ((Slot)slot).setName("Washington Style Straight Slot");
             break;
          case "bonus":
             SlotComponentFactory componentFactory1 = new WaBonusSlot_ComFactory();
             slot = new BonusSlot(componentFactory1);
             ((Slot)slot).setName("Washington Style Bonus Slot");
             break;
          case "progressive":
             SlotComponentFactory componentFactory2 = new WaProgSlot_ComFactory();
             slot = new ProgressiveSlot(componentFactory2);
             ((Slot)slot).setName("Washington Style Progressive Slot");
       }
 
       return (Slot)slot;
    }
}
