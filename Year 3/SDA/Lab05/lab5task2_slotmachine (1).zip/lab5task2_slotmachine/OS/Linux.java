package OS;

public class Linux implements OS{
    public Linux(){

    }

    public String toString(){
        return "Linux";
    }
}
