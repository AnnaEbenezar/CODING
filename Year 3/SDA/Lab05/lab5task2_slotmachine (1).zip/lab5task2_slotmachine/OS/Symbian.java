package OS;

public class Symbian implements OS {
    public Symbian(){
    }

    public String toString(){
        return "Symbian";
    }
}
