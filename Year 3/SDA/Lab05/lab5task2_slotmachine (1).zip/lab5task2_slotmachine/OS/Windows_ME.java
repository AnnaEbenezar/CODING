package OS;

public class Windows_ME implements OS {
    public Windows_ME(){

    }

    public String toString(){
        return "Windows ME";
    }
}
