package OS;

public interface OS {
    String toString();
}
