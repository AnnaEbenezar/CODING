package OS;

public class Andriod implements OS {
    public Andriod(){

    }

    public String toString(){
        return "Android";
    }
}
