package OS;

public class Windows_XP implements OS{
    public Windows_XP(){

    }

    public String toString(){
        return "Windows XP";
    }
}
