package Cabinet;

public class SmallCabinet implements Cabinet{
    public SmallCabinet(){

    }
    public String toString(){
        return "Small Cabinet";
    }
}
