package Cabinet;

public class MediumCabinet implements Cabinet{
    public MediumCabinet(){

    }
    public String toString(){
        return "Medium Cabinet";
    }
}
