package Cabinet;

public class LargeCabinet implements Cabinet{
    public LargeCabinet(){

    }

    public String toString(){
        return "Larbe Cabinet";
    }
}
