package Cabinet;

/**
 * Cabinet
 */
public interface Cabinet {

    String toString();
}