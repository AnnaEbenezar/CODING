import Cabinet.Cabinet;
import Display.Display;
import GPU.GPU;
import OS.OS;
import Payment.Payment;

public interface SlotComponentFactory {
   Cabinet createCabinet();

   Payment createPayment();

   Display createDisplay();

   GPU createGPU();

   OS createOS();
}