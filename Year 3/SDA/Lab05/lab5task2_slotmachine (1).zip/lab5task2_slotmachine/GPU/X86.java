package GPU;

public class X86 implements GPU {
    public X86(){

    }

    public String toString(){
        return "X86";
    }
}
