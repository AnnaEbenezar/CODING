package GPU;

public class X77 implements GPU{
    public X77(){

    }

    public String toString(){
        return "X77";
    }
}
