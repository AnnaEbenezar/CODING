package GPU;

public class ARM implements GPU{
    public ARM(){

    }

    public String toString(){
        return "ARM";
    }
}
