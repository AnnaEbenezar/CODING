package GPU;

public interface GPU {
    String toString();
}
