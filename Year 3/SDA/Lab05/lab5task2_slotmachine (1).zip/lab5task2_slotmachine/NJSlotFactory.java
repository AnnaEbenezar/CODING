public class NJSlotFactory extends SlotFactory{
    public NJSlotFactory() {
    }
 
    protected Slot makeSlot(String item) {
       Slot slot = null;
       switch (item) {
          case "straight":
             SlotComponentFactory componentFactory = new NJStraightSlot_ComFactory();
             slot = new StraightSlot(componentFactory);
             ((Slot)slot).setName("New Jersey Style Straight Slot");
             break;
          case "bonus":
             SlotComponentFactory componentFactory1 = new NJBonusSlot_ComFactory();
             slot = new BonusSlot(componentFactory1);
             ((Slot)slot).setName("New Jersey Style Bonus Slot");
             break;
          case "progressive":
             SlotComponentFactory componentFactory2 = new NJProgSlot_ComFactory();
             slot = new ProgressiveSlot(componentFactory2);
             ((Slot)slot).setName("New Jersey Style Progressive Slot");
       }
 
       return (Slot)slot;
    }
}
