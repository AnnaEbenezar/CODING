import Cabinet.Cabinet;
import Cabinet.MediumCabinet;
import Display.Display;
import Display.LCD;
import GPU.GPU;
import GPU.X77;
import OS.OS;
import OS.Andriod;
import Payment.Payment;
import Payment.ticketin_ticketout;

public class NevProgSlot_ComFactory implements SlotComponentFactory {
    public NevProgSlot_ComFactory() {
   }

   public Cabinet createCabinet() {
      return new MediumCabinet();
   }

   public Payment createPayment() {
      return new ticketin_ticketout();
   }

   public Display createDisplay() {
      return new LCD();
   }

   public GPU createGPU() {
      return new X77();
   }

   public OS createOS() {
      return new Andriod();
   }
}
