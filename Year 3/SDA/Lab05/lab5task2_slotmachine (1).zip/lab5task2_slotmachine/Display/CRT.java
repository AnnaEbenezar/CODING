package Display;

public class CRT implements Display {
    public CRT(){

    }

    public String toString(){
        return "CRT";
    }
}
