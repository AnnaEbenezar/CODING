package Display;

public class Reels implements Display{
    public Reels(){

    }

    public String toString(){
        return "Reels";
    }
}
