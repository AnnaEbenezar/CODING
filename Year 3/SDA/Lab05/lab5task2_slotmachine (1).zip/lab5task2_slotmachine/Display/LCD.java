package Display;

public class LCD implements Display{
    public LCD(){

    }

    public String toString(){
        return "LCD";
    }
}
