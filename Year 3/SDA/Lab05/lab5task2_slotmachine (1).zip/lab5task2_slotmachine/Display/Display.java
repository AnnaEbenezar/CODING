package Display;

/**
 * Display
 */
public interface Display {

    String toString();
}