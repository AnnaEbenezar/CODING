package Display;

public class VGA implements Display{
    public VGA(){

    }

    public String toString(){
        return "VGA";
    }
}
