package Payment;

public class coins implements Payment{
    public coins(){

    }

    public String toString(){
        return "Coins";
    }
}