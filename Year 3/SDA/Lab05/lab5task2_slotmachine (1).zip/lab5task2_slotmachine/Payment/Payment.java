package Payment;

public interface Payment {
    String toString();
} 
