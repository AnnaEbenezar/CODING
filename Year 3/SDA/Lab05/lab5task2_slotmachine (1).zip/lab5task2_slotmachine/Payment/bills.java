package Payment;

public class bills implements Payment{
    public bills(){

    }

    public String toString(){
        return "bills";
    }
}
