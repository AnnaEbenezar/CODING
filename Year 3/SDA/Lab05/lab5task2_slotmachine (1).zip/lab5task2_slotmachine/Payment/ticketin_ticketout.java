package Payment;

public class ticketin_ticketout implements Payment{
    
    public ticketin_ticketout(){

    }

    public String toString(){
        return "Ticket_In Ticket_Out";
    }
}
