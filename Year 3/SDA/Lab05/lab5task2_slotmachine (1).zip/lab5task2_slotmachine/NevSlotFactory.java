public class NevSlotFactory extends SlotFactory{
    public NevSlotFactory() {
    }
 
    protected Slot makeSlot(String item) {
       Slot slot = null;
       switch (item) {
          case "straight":
            SlotComponentFactory componentFactory = new NevStraightSlot_ComFactory();
            slot = new StraightSlot(componentFactory);
            ((Slot)slot).setName("Nevada Style Straight Slot");
            break;
          case "bonus":
            SlotComponentFactory componentFactory1 = new NevBonusSlot_ComFactory();
            slot = new BonusSlot(componentFactory1);
            ((Slot)slot).setName("Nevada Style Bonus Slot");
            break;
          case "progressive":
            SlotComponentFactory componentFactory2 = new NevProgSlot_ComFactory();
            slot = new ProgressiveSlot(componentFactory2);
            ((Slot)slot).setName("Nevada Style Progressive Slot");
       }
 
       return (Slot)slot;
    }
}
