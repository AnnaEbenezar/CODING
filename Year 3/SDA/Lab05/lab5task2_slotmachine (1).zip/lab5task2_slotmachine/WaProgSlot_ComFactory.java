import Cabinet.Cabinet;
import Cabinet.LargeCabinet;
import Display.Display;
import Display.Reels;
import GPU.ARM;
import GPU.GPU;
import OS.OS;
import OS.Andriod;
import Payment.Payment;
import Payment.coins;

public class WaProgSlot_ComFactory implements SlotComponentFactory {
     public WaProgSlot_ComFactory() {
   }

   public Cabinet createCabinet() {
      return new LargeCabinet();
   }

   public Payment createPayment() {
      return new coins();
   }

   public Display createDisplay() {
      return new Reels();
   }

   public GPU createGPU() {
      return new ARM();
   }

   public OS createOS() {
      return new Andriod();
   }
}
