import Cabinet.Cabinet;
import Cabinet.LargeCabinet;
import Display.Display;
import Display.Reels;
import GPU.ARM;
import GPU.GPU;
import OS.Linux;
import OS.OS;
import Payment.Payment;
import Payment.ticketin_ticketout;

public class NevStraightSlot_ComFactory implements SlotComponentFactory{
    public NevStraightSlot_ComFactory() {
   }

   public Cabinet createCabinet() {
      return new LargeCabinet();
   }

   public Payment createPayment() {
      return new ticketin_ticketout();
   }

   public Display createDisplay() {
      return new Reels();
   }

   public GPU createGPU() {
      return new ARM();
   }

   public OS createOS() {
      return new Linux();
   }
}
