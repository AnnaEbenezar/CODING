public class StraightSlot extends Slot{
    SlotComponentFactory componentFactory;

   public StraightSlot(SlotComponentFactory componentFactory) {
      this.componentFactory = componentFactory;
   }

   void build() {
      System.out.println("Building " + this.name);
      this.cabinet = this.componentFactory.createCabinet();
      this.payment = this.componentFactory.createPayment();
      this.display = this.componentFactory.createDisplay();
      this.gpu = this.componentFactory.createGPU();
      this.os = this.componentFactory.createOS();
   }
}
