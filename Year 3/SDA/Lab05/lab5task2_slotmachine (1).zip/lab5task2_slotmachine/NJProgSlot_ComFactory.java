import Cabinet.Cabinet;
import Cabinet.SmallCabinet;
import Display.CRT;
import Display.Display;
import GPU.GPU;
import GPU.X86;
import OS.OS;
import OS.Windows_XP;
import Payment.Payment;
import Payment.bills;

public class NJProgSlot_ComFactory implements SlotComponentFactory {
    public NJProgSlot_ComFactory() {
   }

   public Cabinet createCabinet() {
      return new SmallCabinet();
   }

   public Payment createPayment() {
      return new bills();
   }

   public Display createDisplay() {
      return new CRT();
   }

   public GPU createGPU() {
      return new X86();
   }

   public OS createOS() {
      return new Windows_XP();
   }
}
