import Cabinet.Cabinet;
import Cabinet.SmallCabinet;
import Display.Display;
import Display.CRT;
import GPU.X86;
import GPU.GPU;
import OS.OS;
import OS.Linux;
import Payment.Payment;
import Payment.ticketin_ticketout;


public class NevBonusSlot_ComFactory implements SlotComponentFactory {
    public NevBonusSlot_ComFactory() {
    }
 
    public Cabinet createCabinet() {
       return new SmallCabinet();
    }
 
    public Payment createPayment() {
       return new ticketin_ticketout();
    }
 
    public Display createDisplay() {
       return new CRT();
    }
 
    public GPU createGPU() {
       return new X86();
    }
 
    public OS createOS() {
       return new Linux();
    }
    
}
 