public class SlotMachineApp {
	public static void main(String[] args) {
		SlotFactory njFactory = new NJSlotFactory();
      	SlotFactory nvFactory = new NevSlotFactory();
      	SlotFactory waFactory = new WaSlotFactory();
      	Slot slot1 = njFactory.orderSlot("straight");
      	System.out.println("Customer A ordered a " + slot1 + "\n");
      	Slot slot2 = njFactory.orderSlot("bonus");
      	System.out.println("Customer A ordered a " + slot2 + "\n");
      	Slot slot3 = njFactory.orderSlot("progressive");
      	System.out.println("Customer A ordered a " + slot3 + "\n");
      	Slot slot4 = nvFactory.orderSlot("straight");
      	System.out.println("Customer B ordered a " + slot4 + "\n");
      	Slot slot5 = nvFactory.orderSlot("bonus");
      	System.out.println("Customer B ordered a " + slot5 + "\n");
      	Slot slot6 = nvFactory.orderSlot("progressive");
      	System.out.println("Customer B ordered a " + slot6 + "\n");
      	Slot slot7 = waFactory.orderSlot("straight");
      	System.out.println("Customer C ordered a " + slot7 + "\n");
      	Slot slot8 = waFactory.orderSlot("bonus");
      	System.out.println("Customer C ordered a " + slot8 + "\n");
      	Slot slot9 = waFactory.orderSlot("progressive");
      	System.out.println("Customer C ordered a " + slot9 + "\n");
	}
}
