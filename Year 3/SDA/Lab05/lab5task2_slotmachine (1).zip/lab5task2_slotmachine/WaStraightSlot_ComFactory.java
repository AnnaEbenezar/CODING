import Cabinet.Cabinet;
import Cabinet.LargeCabinet;
import Display.Display;
import Display.Reels;
import GPU.ARM;
import GPU.GPU;
import OS.Linux;
import OS.OS;
import Payment.Payment;
import Payment.bills;

public class WaStraightSlot_ComFactory implements SlotComponentFactory {
    public WaStraightSlot_ComFactory() {
   }

   public Cabinet createCabinet() {
      return new LargeCabinet();
   }

   public Payment createPayment() {
      return new bills();
   }

   public Display createDisplay() {
      return new Reels();
   }

   public GPU createGPU() {
      return new ARM();
   }

   public OS createOS() {
      return new Linux();
   }
}
