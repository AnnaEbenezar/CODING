import javax.swing.*;
import javax.swing.table.*;
import java.util.Vector;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class ScheduleTableModel extends DefaultTableModel {

    private List<TableMemento> mementoHistory = new ArrayList<>();
    public ScheduleTableModel(Object[][] data, Object[] columnNames) {
        super(data, columnNames);
    }
    public void addMementoToHistory(TableMemento memento) {
        mementoHistory.add(memento);
    } 
    public TableMemento createMemento() {
        Vector columnIdentifiers = getDataVector().get(0);
        Vector dataVector = getDataVector();
        TableMemento newMemento = new TableMemento(columnIdentifiers, dataVector);
        mementoHistory.add(newMemento);
        return newMemento;
    }
    public void setMemento(TableMemento memento) {  
        setDataVector(memento.getDataVector(), memento.getColumnIdentifiers());
        fireTableDataChanged();
    }
    public void clearMementoHistory() {
        mementoHistory.clear();
    }
    public TableMemento getMostRecentSnapshot() {   
        if (!mementoHistory.isEmpty()) {
            return mementoHistory.get(mementoHistory.size() - 1);
        }
        return null;
    }
    public void removeMostRecentSnapshot() {
        if (!mementoHistory.isEmpty()) {
            mementoHistory.remove(mementoHistory.size() - 1);
        }
    }
    public void printMementoHistory() {
        System.out.println("Printing Memento History:");
        for (TableMemento memento : mementoHistory) {
            System.out.println(memento);
            System.out.println("_________________________");
        }
    }
    public static class TableMemento implements Serializable {

        private Vector<Object> columnIdentifiers;
        private Vector<Vector<Object>> dataList;
    
        TableMemento(Vector columnIdentifiers, Vector dataVector) {
            this.columnIdentifiers = new Vector(columnIdentifiers);
            this.dataList = new Vector();
            for (Object row : dataVector) {
                Vector rowData = new Vector((Vector)row);
                this.dataList.add(rowData);
            }
        }
        Vector getColumnIdentifiers() {
            return columnIdentifiers;
        }
    
        Vector getDataVector() {
            return dataList;
        }
    
        @Override
        public String toString() {
            return "[ci=" + columnIdentifiers.toString() + "\n" +
                    "dl=" + dataList.toString() + "]";
        }
    
    } 
    
}
